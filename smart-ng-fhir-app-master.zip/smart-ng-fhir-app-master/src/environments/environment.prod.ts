export const environment = {
  production: true,
  showCCDSResourceMenuInstead: false
};
