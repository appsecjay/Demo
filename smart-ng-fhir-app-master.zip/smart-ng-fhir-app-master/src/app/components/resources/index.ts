export * from './edit-resource/edit-resource.component';
export * from './patient/patient.component';
export * from './resources-table/resources-table.component';
export * from './resources-table-container/resources-table-container.component';
